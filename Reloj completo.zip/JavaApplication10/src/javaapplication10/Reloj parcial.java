import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

public class Reloj extends JFrame {

    private JLabel labelHoras, labelMinutos, labelSegundos;
    private Timer timer;
    private int velocidad = 1000; // intervalo de tiempo en milisegundos

    public Reloj() {
        // Crear la ventana
        setTitle("Reloj");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear los componentes de la ventana
        JPanel panel = new JPanel();
        labelHoras = new JLabel();
        labelMinutos = new JLabel();
        labelSegundos = new JLabel();
        JButton botonIniciar = new JButton("Iniciar");
        botonIniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarReloj();
            }
        });
        JButton botonDetener = new JButton("Detener");
        botonDetener.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                detenerReloj();
            }
        });
        JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 2000, 1000);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                velocidad = slider.getValue();
                timer.setDelay(velocidad);
            }
        });

        // Agregar los componentes al panel
        panel.add(labelHoras);
        panel.add(new JLabel(":"));
        panel.add(labelMinutos);
        panel.add(new JLabel(":"));
        panel.add(labelSegundos);
        panel.add(botonIniciar);
        panel.add(botonDetener);
        panel.add(slider);

        // Agregar el panel a la ventana
        add(panel);

        // Mostrar la ventana
        setVisible(true);
    }

    private void iniciarReloj() {
        // Crear el temporizador para actualizar la hora cada segundo
        timer = new Timer(velocidad, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarHora();
            }
        });
        timer.start();
    }

    private void detenerReloj() {
        // Detener el temporizador
        timer.stop();
    }

    private void actualizarHora() {
        // Obtener la hora actual
        long horaActual = System.currentTimeMillis();
        int horas = (int) ((horaActual / (1000 * 60 * 60)) % 24);
        int minutos = (int) ((horaActual / (1000 * 60)) % 60);
        int segundos = (int) (horaActual / 1000) % 60;

        // Actualizar las etiquetas de la hora
        labelHoras.setText(String.format("%02d", horas));
        labelMinutos.setText(String.format("%02d", minutos));
        labelSegundos.setText(String.format("%02d", segundos));
    }

    public static void main(String[] args) {
        Reloj reloj = new Reloj();
    }
}
