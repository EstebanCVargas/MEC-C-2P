import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Reloj extends JFrame implements ActionListener, ChangeListener {
private JLabel horaLabel;
private JButton iniciarButton;
private JButton detenerButton;
private JSlider velocidadSlider;
private int velocidad;
private Timer timer;

public Reloj() {
super("Reloj");
setSize(300, 200);
